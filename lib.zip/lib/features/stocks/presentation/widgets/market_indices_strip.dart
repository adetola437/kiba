part of '../controllers/stocks_controller.dart';

class _MarketIndicesStrip extends StatelessWidget {
  const _MarketIndicesStrip();

  @override
  Widget build(BuildContext context) {
    const indices = [
      _IndexData(label: 'ASI', value: '108,243.51', change: '+0.87%', isUp: true),
      _IndexData(label: 'Market Cap', value: '₦68.4T', change: '+1.2%', isUp: true),
      _IndexData(label: 'Volume', value: '₦3.2B', change: '-0.4%', isUp: false),
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      clipBehavior: Clip.none,
      child: Row(
        children: indices
            .map(
              (idx) => Padding(
                padding: REdgeInsets.only(right: 12),
                child: _IndexChip(data: idx),
              ),
            )
            .toList(),
      ),
    );
  }
}

class _IndexData {
  final String label;
  final String value;
  final String change;
  final bool isUp;
  const _IndexData({
    required this.label,
    required this.value,
    required this.change,
    required this.isUp,
  });
}

class _IndexChip extends StatelessWidget {
  final _IndexData data;
  const _IndexChip({required this.data});

  @override
  Widget build(BuildContext context) {
    final color = data.isUp ? const Color(0xFF1A8C5B) : const Color(0xFFB00020);
    final bgColor =
        data.isUp ? const Color(0xFFEAF7F1) : const Color(0xFFFCE8EB);

    return Container(
      padding: REdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            data.label,
            style: AppTextStyles.labelSmall.copyWith(
              color: AppColors.textDisabled,
              letterSpacing: 0.5,
            ),
          ),
          SizedBox(height: 3.h),
          Text(
            data.value,
            style: AppTextStyles.titleSmall.copyWith(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 4.h),
          Container(
            padding: REdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(6.r),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  data.isUp
                      ? Icons.arrow_upward_rounded
                      : Icons.arrow_downward_rounded,
                  size: 10.r,
                  color: color,
                ),
                SizedBox(width: 2.w),
                Text(
                  data.change,
                  style: AppTextStyles.labelSmall.copyWith(
                    color: color,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}