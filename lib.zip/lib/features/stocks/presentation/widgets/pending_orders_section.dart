// lib/features/stocks/presentation/widgets/pending_orders_section.dart
//
// Drop inside the StockHoldingsSection in portfolio, OR on the
// Stocks hub screen under the watchlist.
// Call: PendingOrdersSection(orders: controller.pendingOrders, onCancel: ...)

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/utils/enums.dart';
import '../../data/stock_order.dart';

class PendingOrdersSection extends StatelessWidget {
  final List<StockOrder> orders;
  final void Function(StockOrder) onCancel;

  const PendingOrdersSection({
    super.key,
    required this.orders,
    required this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Header ─────────────────────────────────────────────────
        Row(
          children: [
            Container(
              width: 8.r,
              height: 8.r,
              decoration: const BoxDecoration(
                color: Color(0xFFF59E0B),
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(width: 8.w),
            Text(
              'Pending Orders',
              style: AppTextStyles.titleLarge.copyWith(
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(width: 8.w),
            Container(
              padding: REdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF3C7),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Text(
                '${orders.length}',
                style: AppTextStyles.labelSmall.copyWith(
                  color: const Color(0xFFB45309),
                  fontWeight: FontWeight.w700,
                  fontSize: 10.sp,
                ),
              ),
            ),
          ],
        ),

        SizedBox(height: 6.h),

        Text(
          'These limit orders will execute automatically when the market price reaches your target.',
          style: AppTextStyles.bodySmall.copyWith(
            color: AppColors.textSecondary,
            height: 1.5,
          ),
        ),

        SizedBox(height: 12.h),

        // ── Order cards ─────────────────────────────────────────────
        ...orders.map(
          (order) => Padding(
            padding: REdgeInsets.only(bottom: 10),
            child: _PendingOrderCard(
              order: order,
              onCancel: () => _showCancelSheet(context, order),
            ),
          ),
        ),
      ],
    );
  }

  void _showCancelSheet(BuildContext context, StockOrder order) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.background,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      builder: (_) => _CancelOrderSheet(
        order: order,
        onConfirm: () {
          Navigator.of(context).pop();
          onCancel(order);
        },
        onDismiss: () => Navigator.of(context).pop(),
      ),
    );
  }
}

// ── Pending order card ─────────────────────────────────────────────────────────
class _PendingOrderCard extends StatelessWidget {
  final StockOrder order;
  final VoidCallback onCancel;

  const _PendingOrderCard({required this.order, required this.onCancel});

  String _fmt(double v) =>
      '₦${NumberFormat('#,##0.00', 'en_US').format(v)}';

  @override
  Widget build(BuildContext context) {
    final isBuy = order.orderType == StockOrderType.buy;
    final currentPrice = order.stock.price;
    final gapPct = order.priceGapPercent(currentPrice);

    // How close is the current price to the limit?
    // progress = 1.0 means triggered, 0.0 means far away
    final double progress = (() {
      if (isBuy) {
        // Buy limit: triggers when price drops TO limitPrice
        // progress: how far price has come down from some reference
        final ref = math.max(currentPrice, order.limitPrice) * 1.05;
        return ((ref - currentPrice) / (ref - order.limitPrice)).clamp(0.0, 1.0);
      } else {
        // Sell limit: triggers when price rises TO limitPrice
        final ref = math.min(currentPrice, order.limitPrice) * 0.95;
        return ((currentPrice - ref) / (order.limitPrice - ref)).clamp(0.0, 1.0);
      }
    })();

    final typeColor = isBuy ? const Color(0xFF1A8C5B) : const Color(0xFFB00020);
    final typeBg = isBuy ? const Color(0xFFEAF7F1) : const Color(0xFFFCE8EB);
    final ticker = order.stock.ticker;

    return Container(
      padding: REdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Top row ──────────────────────────────────────────────
          Row(
            children: [
              // Ticker badge
              Container(
                width: 38.r,
                height: 38.r,
                decoration: BoxDecoration(
                  color: order.stock.iconBg.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: Center(
                  child: Text(
                    ticker.substring(0, ticker.length.clamp(0, 3)),
                    style: AppTextStyles.labelSmall.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w800,
                      fontSize: 9.sp,
                    ),
                  ),
                ),
              ),

              SizedBox(width: 10.w),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          order.stock.ticker,
                          style: AppTextStyles.titleSmall.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(width: 6.w),
                        // BUY / SELL badge
                        Container(
                          padding: REdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: typeBg,
                            borderRadius: BorderRadius.circular(5.r),
                          ),
                          child: Text(
                            isBuy ? 'LIMIT BUY' : 'LIMIT SELL',
                            style: AppTextStyles.labelSmall.copyWith(
                              color: typeColor,
                              fontWeight: FontWeight.w700,
                              fontSize: 8.sp,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      order.stock.name,
                      style: AppTextStyles.bodySmall.copyWith(
                        color: AppColors.textSecondary,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),

              // Pending badge
              Container(
                padding: REdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFFEF3C7),
                  borderRadius: BorderRadius.circular(8.r),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6.r,
                      height: 6.r,
                      decoration: const BoxDecoration(
                        color: Color(0xFFF59E0B),
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Text(
                      'Pending',
                      style: AppTextStyles.labelSmall.copyWith(
                        color: const Color(0xFFB45309),
                        fontWeight: FontWeight.w600,
                        fontSize: 9.sp,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 12.h),
          Divider(color: AppColors.divider, height: 1),
          SizedBox(height: 10.h),

          // ── Order details ─────────────────────────────────────────
          Row(
            children: [
              _Detail(
                label: 'SHARES',
                value: order.shares.toStringAsFixed(
                  order.shares == order.shares.roundToDouble() ? 0 : 2,
                ),
              ),
              _Detail(
                label: 'LIMIT PRICE',
                value: _fmt(order.limitPrice),
              ),
              _Detail(
                label: 'MARKET PRICE',
                value: _fmt(currentPrice),
              ),
            ],
          ),

          SizedBox(height: 12.h),

          // ── Progress bar — how close to trigger ───────────────────
          // Column(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: [
          //     Row(
          //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //       children: [
          //         Text(
          //           isBuy
          //               ? 'Waiting for price to drop'
          //               : 'Waiting for price to rise',
          //           style: AppTextStyles.labelSmall.copyWith(
          //             color: AppColors.textSecondary,
          //             fontSize: 9.sp,
          //           ),
          //         ),
          //         Text(
          //           '${gapPct.toStringAsFixed(1)}% away',
          //           style: AppTextStyles.labelSmall.copyWith(
          //             color: const Color(0xFFB45309),
          //             fontWeight: FontWeight.w600,
          //             fontSize: 9.sp,
          //           ),
          //         ),
          //       ],
          //     ),
          //     SizedBox(height: 6.h),
          //     ClipRRect(
          //       borderRadius: BorderRadius.circular(4.r),
          //       child: LinearProgressIndicator(
          //         value: progress,
          //         minHeight: 5.h,
          //         backgroundColor: AppColors.surfaceVariant,
          //         valueColor: const AlwaysStoppedAnimation(Color(0xFFF59E0B)),
          //       ),
          //     ),
          //   ],
          // ),

          // SizedBox(height: 12.h),

          // ── Expiry + cancel ───────────────────────────────────────
          Row(
            children: [
              Icon(Icons.schedule_rounded,
                  size: 12.r, color: AppColors.textDisabled),
              SizedBox(width: 4.w),
              Text(
                'Expires ${DateFormat('d MMM y').format(order.expiresAt)}',
                style: AppTextStyles.bodySmall.copyWith(
                  color: AppColors.textDisabled,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: onCancel,
                child: Container(
                  padding:
                      REdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(
                      color: AppColors.buttonBorder,
                      width: 1.5,
                    ),
                  ),
                  child: Text(
                    'Cancel Order',
                    style: AppTextStyles.labelSmall.copyWith(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Cancel confirmation sheet ──────────────────────────────────────────────────
class _CancelOrderSheet extends StatelessWidget {
  final StockOrder order;
  final VoidCallback onConfirm;
  final VoidCallback onDismiss;

  const _CancelOrderSheet({
    required this.order,
    required this.onConfirm,
    required this.onDismiss,
  });

  String _fmt(double v) =>
      '₦${NumberFormat('#,##0.00', 'en_US').format(v)}';

  @override
  Widget build(BuildContext context) {
    final isBuy = order.orderType == StockOrderType.buy;

    return SingleChildScrollView(
      child: Padding(
        padding: REdgeInsets.fromLTRB(24, 8, 24, 40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Drag handle
            Center(
              child: Container(
                width: 40.w,
                height: 4.h,
                margin: REdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
            ),
      
            // Icon
            Container(
              width: 48.r,
              height: 48.r,
              decoration: BoxDecoration(
                color: const Color(0xFFFEF3C7),
                borderRadius: BorderRadius.circular(14.r),
              ),
              child: Icon(
                Icons.cancel_outlined,
                size: 24.r,
                color: const Color(0xFFB45309),
              ),
            ),
      
            SizedBox(height: 14.h),
      
            Text(
              'Cancel this order?',
              style: AppTextStyles.titleLarge.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w700,
              ),
            ),
      
            SizedBox(height: 6.h),
      
            Text(
              'Your ${isBuy ? 'buy' : 'sell'} order for ${order.shares.toStringAsFixed(0)} shares of ${order.stock.ticker} at ${_fmt(order.limitPrice)} will be cancelled. No funds will be deducted.',
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.textSecondary,
                height: 1.5,
              ),
            ),
      
            SizedBox(height: 24.h),
      
            // Order summary
            Container(
              padding: REdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Column(
                children: [
                  _SheetRow(label: 'Stock', value: order.stock.ticker),
                  SizedBox(height: 8.h),
                  _SheetRow(
                      label: 'Order type',
                      value: isBuy ? 'Limit Buy' : 'Limit Sell'),
                  SizedBox(height: 8.h),
                  _SheetRow(
                      label: 'Shares',
                      value: order.shares.toStringAsFixed(0)),
                  SizedBox(height: 8.h),
                  _SheetRow(
                      label: 'Limit price', value: _fmt(order.limitPrice)),
                ],
              ),
            ),
      
            SizedBox(height: 24.h),
      
            // Buttons
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: onDismiss,
                    child: Container(
                      height: 52.h,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14.r),
                        border: Border.all(
                            color: AppColors.buttonBorder, width: 1.5),
                      ),
                      child: Text(
                        'Keep Order',
                        style: AppTextStyles.labelLarge.copyWith(
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: GestureDetector(
                    onTap: onConfirm,
                    child: Container(
                      height: 52.h,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFB00020),
                        borderRadius: BorderRadius.circular(14.r),
                      ),
                      child: Text(
                        'Yes, Cancel',
                        style: AppTextStyles.labelLarge.copyWith(
                          color: AppColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Helpers ────────────────────────────────────────────────────────────────────
class _Detail extends StatelessWidget {
  final String label;
  final String value;
  const _Detail({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: AppTextStyles.labelSmall.copyWith(
                color: AppColors.textDisabled,
                fontSize: 8.sp,
                letterSpacing: 0.5,
              )),
          SizedBox(height: 2.h),
          Text(value,
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.textPrimary,
                fontWeight: FontWeight.w600,
              )),
        ],
      ),
    );
  }
}

class _SheetRow extends StatelessWidget {
  final String label;
  final String value;
  const _SheetRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: AppTextStyles.bodySmall
                .copyWith(color: AppColors.textSecondary)),
        Text(value,
            style: AppTextStyles.bodySmall.copyWith(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
            )),
      ],
    );
  }
}