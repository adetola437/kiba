part of '../controllers/stock_detail_controller.dart';

class StockDetailView extends StatelessWidget implements StockDetailViewContract {
  const StockDetailView({super.key, required this.controller});

  final StockDetailControllerContract controller;

  String _fmt(double v) =>
      '₦${NumberFormat('#,##0.00', 'en_US').format(v)}';

  @override
  Widget build(BuildContext context) {
    final stock = controller.stock;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: CustomAppBar(title: stock.ticker),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: REdgeInsets.fromLTRB(20, 8, 20, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Price header ─────────────────────────────────
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            stock.formattedPrice,
                            style: AppTextStyles.displaySmall.copyWith(
                              fontFamily: 'BWGradual',
                              color: AppColors.textPrimary,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          Row(
                            children: [
                              Icon(
                                stock.isGainer
                                    ? Icons.arrow_upward_rounded
                                    : Icons.arrow_downward_rounded,
                                size: 14.r,
                                color: stock.changeColor,
                              ),
                              SizedBox(width: 4.w),
                              Text(
                                '${stock.isGainer ? '+' : ''}${_fmt(stock.changeAmount)} (${stock.formattedChange})',
                                style: AppTextStyles.bodyMedium.copyWith(
                                  color: stock.changeColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const Spacer(),
                      Container(
                        padding:
                            REdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceVariant,
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        child: Text(
                          'Today',
                          style: AppTextStyles.labelSmall.copyWith(
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 24.h),

                  // ── Price chart ──────────────────────────────────
                  _StockPriceChart(
                    stock: stock,
                    selectedRange: controller.selectedRange,
                    onRangeChanged: controller.onRangeChanged,
                  ),

                  SizedBox(height: 28.h),

                  // ── Day's range ──────────────────────────────────
                  Text(
                    "Today's Range",
                    style: AppTextStyles.titleSmall.copyWith(
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 10.h),
                  _DayRangeBar(stock: stock),

                  SizedBox(height: 28.h),

                  // ── Key stats ────────────────────────────────────
                  Text(
                    'Key Statistics',
                    style: AppTextStyles.titleSmall.copyWith(
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 14.h),
                  _StockStatsGrid(stock: stock),

                  SizedBox(height: 28.h),

                  // ── About company ────────────────────────────────
                  Text(
                    'About ${stock.name}',
                    style: AppTextStyles.titleSmall.copyWith(
                      color: AppColors.textPrimary,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    '${stock.name} (${stock.ticker}) is listed on the Nigerian Exchange Group (NGX) under the ${_sectorLabel(stock.sector)} sector. The company is one of the leading players in its industry with a market capitalisation of ₦${stock.marketCap.toStringAsFixed(2)} trillion.',
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textSecondary,
                      height: 1.6,
                    ),
                  ),

                  SizedBox(height: 12.h),
                ],
              ),
            ),
          ),

          // ── Bottom action buttons ────────────────────────────────
          Container(
            padding: REdgeInsets.fromLTRB(20, 12, 20, 32),
            decoration: BoxDecoration(
              color: AppColors.background,
              border: Border(top: BorderSide(color: AppColors.divider)),
            ),
            child: Row(
              children: [
                // Sell button
                Expanded(
                  child: GestureDetector(
                    onTap: controller.onSellTap,
                    child: Container(
                      height: 54.h,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(14.r),
                        border: Border.all(
                          color: AppColors.buttonBorder,
                          width: 1.5,
                        ),
                      ),
                      child: Text(
                        'Sell',
                        style: AppTextStyles.labelLarge.copyWith(
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(width: 12.w),

                // Buy button
                Expanded(
                  flex: 2,
                  child: GestureDetector(
                    onTap: controller.onBuyTap,
                    child: Container(
                      height: 54.h,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(14.r),
                      ),
                      child: Text(
                        'Buy ${stock.ticker}',
                        style: AppTextStyles.labelLarge.copyWith(
                          color: AppColors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _sectorLabel(StockSector s) {
    switch (s) {
      case StockSector.finance:
        return 'Banking & Finance';
      case StockSector.telecoms:
        return 'Telecommunications';
      case StockSector.energy:
        return 'Oil & Energy';
      case StockSector.consumer:
        return 'Consumer Goods';
      case StockSector.technology:
        return 'Technology';
      case StockSector.health:
        return 'Healthcare';
      default:
        return 'General';
    }
  }
}

// ── Day range bar ──────────────────────────────────────────────────────────────
class _DayRangeBar extends StatelessWidget {
  final StockData stock;
  const _DayRangeBar({required this.stock});

  String _fmt(double v) =>
      stock.isNigerian ? '₦${v.toStringAsFixed(2)}' : '\$${v.toStringAsFixed(2)}';

  @override
  Widget build(BuildContext context) {
    final range = stock.highPrice - stock.lowPrice;
    final position = range < 0.01
        ? 0.5
        : ((stock.price - stock.lowPrice) / range).clamp(0.0, 1.0);

    return Column(
      children: [
        // Progress bar
        ClipRRect(
          borderRadius: BorderRadius.circular(4.r),
          child: Stack(
            children: [
              Container(
                height: 6.h,
                color: AppColors.surfaceVariant,
              ),
              FractionallySizedBox(
                widthFactor: position,
                child: Container(
                  height: 6.h,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFFB00020),
                        AppColors.primary,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 8.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Low: ${_fmt(stock.lowPrice)}',
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.textSecondary,
              ),
            ),
            Text(
              'Open: ${_fmt(stock.openPrice)}',
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.textSecondary,
              ),
            ),
            Text(
              'High: ${_fmt(stock.highPrice)}',
              style: AppTextStyles.bodySmall.copyWith(
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ],
    );
  }
}