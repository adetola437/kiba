part of '../controllers/stocks_controller.dart';

class StocksView extends StatelessWidget implements StocksViewContract {
  const StocksView({super.key, required this.controller});

  final StocksControllerContract controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // ── App Bar ──────────────────────────────────────────────────
         const SliverAppBar(
            backgroundColor: AppColors.background,
            floating: true,
            snap: true,
            elevation: 0,
            scrolledUnderElevation: 0,
            titleSpacing: 0,
            automaticallyImplyLeading: false,
            title: CustomAppBar(title: 'Stocks'),
            // title: Padding(
            //   padding: REdgeInsets.symmetric(horizontal: 20),
            //   child: controller.isSearching
            //       ? _SearchBar(controller: controller)
            //       : Row(
            //           children: [
            //             Text(
            //               'Stocks',
            //               style: AppTextStyles.headlineMedium.copyWith(
            //                 fontFamily: 'BWGradual',
            //                 color: AppColors.textPrimary,
            //               ),
            //             ),
            //             const Spacer(),
            //             GestureDetector(
            //               onTap: controller.onToggleSearch,
            //               child: Container(
            //                 width: 38.r,
            //                 height: 38.r,
            //                 decoration: BoxDecoration(
            //                   color: AppColors.surfaceVariant,
            //                   shape: BoxShape.circle,
            //                 ),
            //                 child: Icon(
            //                   Icons.search_rounded,
            //                   size: 18.r,
            //                   color: AppColors.textPrimary,
            //                 ),
            //               ),
            //             ),
            //             SizedBox(width: 10.w),
            //             GestureDetector(
            //               onTap: () {},
            //               child: Container(
            //                 width: 38.r,
            //                 height: 38.r,
            //                 decoration: BoxDecoration(
            //                   color: AppColors.surfaceVariant,
            //                   shape: BoxShape.circle,
            //                 ),
            //                 child: Icon(
            //                   Icons.tune_rounded,
            //                   size: 18.r,
            //                   color: AppColors.textPrimary,
            //                 ),
            //               ),
            //             ),
            //           ],
            //         ),
            // ),
          ),

          SliverPadding(
            padding: REdgeInsets.fromLTRB(20, 8, 20, 40),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // ── Hero Banner ─────────────────────────────────────
                const _StocksHeroBanner(),

                SizedBox(height: 20.h),

                // ── Market Indices Strip ─────────────────────────────
                const _MarketIndicesStrip(),

                SizedBox(height: 24.h),

                // ── Watchlist ────────────────────────────────────────
                if (controller.watchlist.isNotEmpty) ...[
                  _StocksWatchlistSection(
                    watchlist: controller.watchlist,
                    onStockTap: controller.onStockTap,
                  ),
                  SizedBox(height: 24.h),
                ],

                // ── Section header ───────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'NGX Listed Stocks',
                      style: AppTextStyles.titleLarge.copyWith(
                        color: AppColors.textPrimary,
                      ),
                    ),
                    GestureDetector(
                      onTap: controller.onSeeAllTap,
                      child: Text(
                        'See all',
                        style: AppTextStyles.labelMedium.copyWith(
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 14.h),

                // ── Sector tabs ──────────────────────────────────────
                _SectorTabs(
                  active: controller.activeSector,
                  onChanged: controller.onSectorChanged,
                ),

                SizedBox(height: 16.h),

                // ── Stock list ───────────────────────────────────────
                if (controller.isLoading) ...[
                  const _StockCardSkeleton(),
                  SizedBox(height: 12.h),
                  const _StockCardSkeleton(),
                  SizedBox(height: 12.h),
                  const _StockCardSkeleton(),
                ] else if (controller.filteredStocks.isEmpty)
                  _EmptyStocksState()
                else ...[
                  ...controller.filteredStocks.map(
                    (stock) => Padding(
                      padding: REdgeInsets.only(bottom: 12),
                      child: _StockCard(
                        stock: stock,
                        onTap: () => controller.onStockTap(stock),
                      ),
                    ),
                  ),
                ],

                SizedBox(height: 8.h),

                // ── Disclaimer ───────────────────────────────────────
                Container(
                  padding: REdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.info_outline_rounded,
                        size: 14.r,
                        color: AppColors.textDisabled,
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          'Stock prices are delayed by 15 minutes. Past performance does not guarantee future results. Investments in stocks carry risk including loss of capital.',
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.textDisabled,
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Search bar ─────────────────────────────────────────────────────────────────
class _SearchBar extends StatelessWidget {
  final StocksControllerContract controller;
  const _SearchBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: 42.h,
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: TextField(
              autofocus: true,
              onChanged: controller.onSearchChanged,
              style: AppTextStyles.bodyMedium,
              decoration: InputDecoration(
                border: InputBorder.none,
                contentPadding:
                    REdgeInsets.symmetric(horizontal: 14, vertical: 12),
                hintText: 'Search ticker or company…',
                hintStyle: AppTextStyles.bodyMedium
                    .copyWith(color: AppColors.textDisabled),
                prefixIcon: Icon(
                  Icons.search_rounded,
                  size: 18.r,
                  color: AppColors.textDisabled,
                ),
              ),
            ),
          ),
        ),
        SizedBox(width: 10.w),
        GestureDetector(
          onTap: controller.onToggleSearch,
          child: Text(
            'Cancel',
            style: AppTextStyles.labelMedium.copyWith(
              color: AppColors.primary,
            ),
          ),
        ),
      ],
    );
  }
}

// ── Empty state ────────────────────────────────────────────────────────────────
class _EmptyStocksState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: REdgeInsets.symmetric(vertical: 48),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.search_off_rounded,
            size: 48.r,
            color: AppColors.primary.withOpacity(0.2),
          ),
          SizedBox(height: 12.h),
          Text(
            'No stocks match your search.',
            style: AppTextStyles.bodyMedium.copyWith(
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}