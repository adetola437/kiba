part of '../controllers/kyc_tier2_controller.dart';

class KycDocumentUpload extends StatelessWidget {
  const KycDocumentUpload({super.key, required this.state, required this.onUpload, required this.onRemove});

  final DocUploadState state;
  final VoidCallback onUpload;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: REdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 36.r, height: 36.r,
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(state.icon, size: 18.r, color: AppColors.textPrimary),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(state.label, style: AppTextStyles.titleSmall.copyWith(color: AppColors.textPrimary)),
                SizedBox(height: 4.h),
                Text(state.hint, style: AppTextStyles.bodySmall.copyWith(color: AppColors.textSecondary)),
              ],
            ),
          ),
          SizedBox(width: 8.w),
          if (state.status == DocUploadStatus.empty) ...[
            GestureDetector(onTap: onUpload, child: Icon(Icons.upload_file_outlined, color: AppColors.primary)),
          ] else if (state.status == DocUploadStatus.uploading) ...[
            SizedBox(
              width: 60.r,
              child: LinearProgressIndicator(value: state.uploadProgress),
            ),
          ] else ...[
            GestureDetector(onTap: onRemove, child: Icon(Icons.delete_outline, color: Colors.red)),
          ]
        ],
      ),
    );
  }
}
